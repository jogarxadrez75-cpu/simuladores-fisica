# 🧪 Simuladores de Física

Simuladores interativos em HTML puro, sem instalação. Abra no navegador e brinque.

## Simuladores

| Simulador | Descrição |
|---|---|
| [⚡ Laboratório Maluco de Cargas](campo-eletrico/) | Cargas elétricas, linhas de campo, potencial, energia e circuitos com instrumentos de medida |

## Como adicionar um novo simulador

1. Crie uma pasta nova, por exemplo `pendulo/`, e coloque nela um arquivo `index.html`.
2. Em `index.html` (na raiz), copie um bloco `<a class="card">` e ajuste o link, o ícone, o título e a descrição.
3. Acrescente uma linha na tabela acima.
4. Faça commit. O site atualiza sozinho em cerca de um minuto.
